const result = document.querySelector('#result');       
const table = document.querySelector('#mytable');       
const btn = document.querySelector('.search');          
const searchKey = document.querySelector('#searchkey'); 
var contactArr = [          
              
["vijay khanna sir","211, 267"],          
["kishore khanna sir","213, 257"],        
["lalit khanna sir","229, 246"],          
["neeraj khanna sir","247, 340"],         
["saourabh khanna sir","282, 249"],       
["rohit khanna sir","215, 233"],          
["sahil khanna sir","252"], 
["lakshya khanna sir","357"],             
["mohit khanna sir","357"], 
["mohit agarwal","343"],    
["atar singh","217"],       
["cp singh","220"],         
["rajendra kumar sharma","210"],          
["sunil kumar sharma","241"],             
["ravi kumar","289"],       
["pankaj nagpal","299"],    
["radhey shaym","310"],     
["ravikant / naresh","273"],              
["neelkamal","333"],        
["it dept.","311"],         
["shailendra kumar","237"], 
["shailja","337"],          
["anurag","214"],           
["narendra kumar rajpal","292"],          
["dheeraj sharma","388"],   
["yashpal singh chahar","294"],           
["yogesh agrawal, ankit","326"],          
["harendra, akash verma","307"],          
["trigun wahal, sarvesh","373"],          
["adarsh kumar chahar","395"],            
["praveen gupta, pradeep verma","324"],   
["vijay kumar arora","274"],              
["ajit singh","387"],       
["ram lakhan tyagi","335"], 
["shailendra mudgal","389"],              
["harish kumar saraswat","216"],          
["board room","234"],       
["r & d meeting room","306"],             
["management meeting room","293"],        
["vinay kumar saraswat","290"],           
["ankit garg","323"],       
["anshish kumar","350"],    
["rahul agrawal","316"],    
["vineet singh","338"],     
["kishore kumar wadhwa","277"],           
["arvind kumar","393"],     
["sanjeev kumar","301"],    
["harish kumar","303"],     
["shashank singh (dispatch)","260"],      
["sandip kumar (dispatch)","279"],        
["ashish kumar  (dispatch)","361"],       
["brajesh kumar, govind singh","242"],    
["mahima","374"],           
["vandana arora","344"],    
["dinesh singh sikarwar","315"],          
["bharti varshney","359"],  
["dheeraj","240"],          
["cl yadav","254"],         
["yatendra pal singh","339"],             
["Sony Accounts","428"],    
["Sanjay Ji RI","6041"]     
    ];        
              
    contactArr.forEach(function(val){     
        table.innerHTML+=`<tr><td>${val[0]}</td><td>${val[1]}</td></tr>`            
    })        
    btn.addEventListener("click",function(){            
        result.innerHTML="" 
       contactArr.forEach(function(val){  
       var searchStr = searchKey.value    
       var newStr = searchStr.toString().toLowerCase(); 
        if(val[0].toLowerCase().includes(newStr) && searchKey.value != ""){         
            result.innerHTML+=`<tr><td>${val[0]}</td><td style="width:120px">${val[1]}</td></tr>` 
        }else if(val[1].includes(searchKey.value) && searchKey.value != ""){        
            result.innerHTML+=`<tr><td>${val[0]}</td><td style="width:120px">${val[1]}</td></tr>` 
        }     
       })     
    })        
    window.addEventListener("keydown",function(e){      
        if(e.key == "Enter"){             
            btn.click()     
        }     
    })        
