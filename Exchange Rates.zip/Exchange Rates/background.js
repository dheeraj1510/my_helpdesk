var table = document.querySelector("#mytable");
var updateDate = document.querySelector("#updt");
var openSite = document.querySelector("#openSite");
var loader = document.querySelector(".coverPage");
/*
    function testFunc(){
        console.log("OK");
        fetch("https://script.google.com/macros/s/AKfycbxllRXjHvjmtWYhZ02VUYAvwqj7j1ISioGbam8q87tzSN467oTa40kJ5qqaj31U7_PWrQ/exec")
    .then(function(response){
        return response.json();
    }).then(function(data){
        var newData = data.content

        newData.forEach(function(val,i){
            table.innerHTML+=`<tr><td>${newData[i][0]}</td><td>${newData[i][1]}</td><td>${newData[i][2]}</td></tr>`
        });
updateDate.innerText=newData[0][3];
        loader.style.display="none";
    })
    }
testFunc();

*/
fetch("https://script.google.com/macros/s/AKfycbwL3OXxAOKmCWGdDTwvbyGNl93HM9rLZmxG97rDzAGFhw249jiiZ8NiNuPrsljUjbxGSQ/exec")
.then(function (params) {
    return params.text()
}).then(function (data) {
    var currencyData = [data.slice(data.indexOf("USD :"),data.indexOf("GBP")),
    data.slice(data.indexOf("GBP :"),data.indexOf("EUR")),
    data.slice(data.indexOf("EUR "),data.length)]

    table.innerHTML+=`<tr><td>currency</td><td>Export Rates</td></tr>`

    for(i=0; i<currencyData.length; i++){
        var newData = currencyData[i].split(":");
        table.innerHTML+=`<tr><td>${newData[0]}</td><td>${parseFloat(newData[1]).toFixed(2)}</td></tr>`
    }

    updateDate.innerText=data.slice(data.indexOf("TRUE")+5,data.indexOf("curr.cbicImport"));

    loader.style.display="none";
})

openSite.addEventListener("click",function(){
    window.open("https://my-publish-web-application.on.drv.tw/myhelpdesk");
    })


