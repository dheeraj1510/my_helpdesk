var notifyUrl = window.location.href;

  var scriptId = "AKfycbxcsXLzJMO107aloKEIUd59-1iqPpWJA9fOzl0V6-EzhAB5UOWY3b0lF4PUIs57X1I2"
  
  document.addEventListener('DOMContentLoaded', function() {
   if (!Notification) {
    alert('Desktop notifications not available in your browser. Try Chromium.');
    return;
   }
  
   if (Notification.permission !== 'granted' && notifyUrl.includes("mail.google"))
    Notification.requestPermission();
  });
  
  //setInterval(notifyMe, 10000);
  console.clear();
  fetch(`https://script.google.com/macros/s/${scriptId}/exec`)
      .then(response => {
        return response.json();
      })
      .then(function(data){
        var notificData = data.content[1];
        if(notificData[0] == "TRUE"){
          notifyMe(notificData[1],notificData[2],notificData[3],notificData[4]);
        }else
	if(notificData[0] == "FALSE"){
	
	}
      })
  
  
  function notifyMe(ttl,iconic,bdy,siteUrl) {
   /*if (Notification.permission !== 'granted'){
    Notification.requestPermission();
   }else if(notifyUrl.includes("mail.google")){*/
    var notification = new Notification(ttl, {
     icon: iconic,
     body: bdy,
    });
    notification.onclick = function() {
     if(siteUrl != ""){
      window.open(siteUrl);
      postData();
     }else{
  }
      
    };
      // postData();
   //}
  }
  
  
  function postData(){
  
  obj2 = {
    status:"FALSE"
  }
  
  fetch("https://script.google.com/macros/s/"+scriptId+"/exec",{
    method: 'POST',
    body: JSON.stringify(obj2),
  })
  .then((response) =>{
    return response.text();
  })
  .then((data) =>{ 
  
  console.log(data);
  
  });
  }